package prototype;

public interface UMLShape {
    void draw();
    UMLShape clone();
}
