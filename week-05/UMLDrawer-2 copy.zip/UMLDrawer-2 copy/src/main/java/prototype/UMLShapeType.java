package prototype;

public enum UMLShapeType {
    GENERALISATION,
    IMPLEMENTATION,
    USE_CASE,
    ACTOR,
    USE_CASE_DIAGRAM,
    UML_CLASS,
    BASIC_LINE
}
